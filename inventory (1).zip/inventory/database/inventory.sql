CREATE TABLE `products` (
  `product_id` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_quantity` decimal(10,2) NOT NULL,
  `product_date_created` varchar(255) NOT NULL,
  PRIMARY KEY (`product_id`)
);

INSERT INTO `products` (`product_id`, `product_name`, `product_price`, `product_quantity`, `product_date_created`) VALUES
('1000', 'DUMU ZAS IRON SHEET 2 METERS', 1000.00, 20.00, '2025-02-19 23:43:13'),
('1001', 'DUMU ZAS IRON SHEET 2.5 METERS', 1200.00, 32.00, '2025-02-19 23:43:39'),
('1002', 'DUMU ZAS IRON SHEET 3 METERS', 1300.00, 10.00, '2025-02-19 23:44:03'),
('1003', 'SQUARE TUBE 0.75&quot;', 500.00, 35.00, '2025-02-19 23:44:42'),
('1004', 'SQUARE TUBE 0.5&quot;', 600.00, 15.00, '2025-02-19 23:59:09'),
('1005', 'SQUARE TUBE 1&quot;', 700.00, 35.00, '2025-02-19 23:59:38'),
('1006', 'SQUARE TUBE 1.5&quot;', 800.00, 40.00, '2025-02-20 00:00:12'),
('1007', 'SQUARE TUBE 2&quot;', 900.00, 16.00, '2025-02-20 00:00:52'),
('1008', 'SQUARE TUBE 2.5&quot;', 1000.00, 5.00, '2025-02-20 00:01:20'),
('1009', 'SQUARE TUBE 3&quot;', 1100.00, 10.00, '2025-02-20 00:01:46'),
('1010', 'SQUARE TUBE 3.5&quot;', 1200.00, 10.00, '2025-02-20 00:02:18');
