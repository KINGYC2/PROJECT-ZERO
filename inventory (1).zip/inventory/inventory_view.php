<?php
    require 'database_connection.php';

    date_default_timezone_set('Africa/Nairobi');
    $currentTime = date('Y-m-d H:i:s');

    session_start();

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addProduct'])) {
        $productID = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['productID']),ENT_QUOTES,'UTF-8')));
        $productName = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['productName']),ENT_QUOTES,'UTF-8')));
        $productPrice = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['productPrice']),ENT_QUOTES,'UTF-8')));
        $productQuantity = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['productQuantity']),ENT_QUOTES,'UTF-8')));

        if (isset($productID) == false) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product id is not set';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_id_not_set&task=add_product');
            exit();
        }
        if (empty($productID) == true) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product id is empty';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_id_empty&task=add_product');
            exit();
        }

        if (isset($productName) == false) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product name is not set';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_name_not_set&task=add_product');
            exit();
        }
        if (empty($productName) == true) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product name is empty';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_name_empty&task=add_product');
            exit();
        }

        if (isset($productPrice) == false) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product_price is not set';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_price_not_set&task=add_product');
            exit();
        }
        if (empty($productPrice) == true) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product_price is empty';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_price_empty&task=add_product');
            exit();
        }

        if (isset($productQuantity) == false) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product quantity is not set';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_quantity_not_set&task=add_product');
            exit();
        }
        if (empty($productQuantity) == true) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product quantity is empty';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_quantity_empty&task=add_product');
            exit();
        }
        
        $productID = strval($productID);
        $available_product_id_sql = 'SELECT `product_id` FROM `products` WHERE `product_id`=?';
        $available_product_id_stmt = $db_connection->prepare($available_product_id_sql);
        $available_product_id_stmt->bind_param('s',$productID);
        $available_product_id_stmt->execute();
        $available_product_id_stmt_result = $available_product_id_stmt->get_result();
        if (intval($available_product_id_stmt_result->num_rows) !==0) {
            $_SESSION['inventory_title'] = 'Error';
            $_SESSION['inventory_text'] = 'Product id already exixts';
            $_SESSION['inventory_icon'] = 'error';
            header('Location:inventory_view.php?error=product_id_exixts&task=add_product');
            exit();
        } else {
            $add_product_sql = 'INSERT INTO `products`(`product_id`,`product_name`,`product_price`,`product_quantity`,`product_date_created`) VALUES (?,?,?,?,?)';
            $add_product_stmt = $db_connection->prepare($add_product_sql);
            $add_product_stmt->bind_param('sssss',$productID,$productName,$productPrice,$productQuantity,$currentTime);
            if (!$add_product_stmt->execute()) {
                $_SESSION['inventory_title'] = 'Error';
                $_SESSION['inventory_text'] = 'There was an error while adding the product';
                $_SESSION['inventory_icon'] = 'error';
                header('Location:inventory_view.php?error=error_adding_product&task=add_product');
                exit();
            } else {
                $_SESSION['inventory_title'] = 'Success';
                $_SESSION['inventory_text'] = 'Product was added successfully';
                $_SESSION['inventory_icon'] = 'success';
                header('Location:inventory_view.php?success=product_added_successfully&task=add_product');
                exit();
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Inventory system</title>
        <link rel="stylesheet" href="inventory.css">
    </head>
    <body>
        <div class="container">
            <h1>Inventory Management System</h1>

            <form action="" method="post">
                <div class="form-group">
                    <label for="productID">Product ID</label>
                    <input type="text" name="productID" id="productID" placeholder="Enter Product ID" autocomplete="off" autofocus>
                </div>
                
                <div class="form-group">
                    <label for="productName">Product Name</label>
                    <input type="text" name="productName" id="productName" placeholder="Enter Product Name" autocomplete="off">
                </div>
                
                <div class="form-group">
                    <label for="productPrice">Product Price</label>
                    <input type="number" name="productPrice" id="productPrice" placeholder="Enter Product Price" autocomplete="off">
                </div>
                
                <div class="form-group">
                    <label for="productQuantity">Product Quantity</label>
                    <input type="number" name="productQuantity" id="productQuantity" placeholder="Enter Product Quantity" autocomplete="off">
                </div>

                <button type="submit" name="addProduct" id="addProduct">Add Product</button>
            </form>

            <h2>Inventory</h2>
            <table id="inventoryTable">
                <thead>
                    <tr>
                        <th>Product id</th>
                        <th>Product name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Date created</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $available_products_sql = 'SELECT `product_id`, `product_name`, `product_price`, `product_quantity`, `product_date_created` FROM `products` ORDER BY `product_id` ASC';
                        $available_products_stmt = $db_connection->prepare($available_products_sql);
                        $available_products_stmt->execute();
                        $available_products_stmt_result = $available_products_stmt->get_result();
                    ?>
                    <?php while ($available_products_assoc = $available_products_stmt_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars_decode($available_products_assoc['product_id']); ?></td>
                            <td><?php echo htmlspecialchars_decode($available_products_assoc['product_name']); ?></td>
                            <td><?php echo htmlspecialchars_decode(number_format($available_products_assoc['product_price'], 2)); ?></td>
                            <td><?php echo htmlspecialchars_decode(number_format($available_products_assoc['product_quantity'], 2)); ?></td>
                            <td><?php echo htmlspecialchars_decode($available_products_assoc['product_date_created']); ?></td>
                            <td>
                                <button class="edit-btn" data-product-id="<?php echo htmlspecialchars_decode($available_products_assoc['product_id']); ?>">
                                    Edit
                                </button>
                                <button class="delete-btn" data-product-id="<?php echo htmlspecialchars_decode($available_products_assoc['product_id']); ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <script>
                document.querySelectorAll('.edit-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const productId = this.getAttribute('data-product-id');
                        editItem(productId);
                    });
                });

                document.querySelectorAll('.delete-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const productId = this.getAttribute('data-product-id');
                        deleteItem(productId);
                    });
                });

                function refreshTableRow(productId, updatedProduct) {
                    const row = document.querySelector(`button[data-product-id="${productId}"]`).closest('tr');

                    row.innerHTML = `
                        <td>${updatedProduct.product_id}</td>
                        <td>${updatedProduct.product_name}</td>
                        <td>${updatedProduct.product_price}</td>
                        <td>${updatedProduct.product_quantity}</td>
                        <td>${updatedProduct.product_date_created}</td>
                        <td>
                            <button class="edit-btn" data-product-id="${updatedProduct.product_id}" onclick="editItem(${updatedProduct.product_id})">Edit</button>
                            <button class="delete-btn" data-product-id="${updatedProduct.product_id}" onclick="deleteItem(${updatedProduct.product_id})">Delete</button>
                        </td>
                    `;
                }

                function editItem(productId) {
                    const newProductName = prompt('Enter new product name:');
                    const newProductPrice = prompt('Enter new product price:');
                    const newProductQuantity = prompt('Enter new product quantity:');

                    if (newProductName && !isNaN(newProductQuantity) && newProductQuantity > 0 && !isNaN(newProductPrice) && newProductPrice > 0) {
                        $.ajax({
                            url: 'inventory_edit_product.php',
                            type: 'POST',
                            data: {
                                product_id: productId,
                                product_name: newProductName,
                                product_price: newProductPrice,
                                product_quantity: newProductQuantity
                            },
                            success: function(response) {
                                const updatedProduct = response.data;

                                refreshTableRow(productId, updatedProduct);
                            },
                            error: function(xhr, status, error) {
                                console.error('Error:', error);
                                alert('An error occurred while updating the product.');
                            }
                        });
                    } else {
                        alert('Invalid input. Please check the details and try again.');
                    }
                }

                function deleteItem(productId) {
                    if (confirm('Are you sure you want to delete this product?')) {
                        $.ajax({
                            url: 'inventory_delete_product.php',
                            type: 'POST',
                            data: { 
                                product_id: productId
                            },
                            success: function(response) {
                                try {
                                    var delete_product_json_response = JSON.parse(response);

                                    if (delete_product_json_response.status === 'success') {
                                        alert(delete_product_json_response.message);
                                        document.querySelector(`button[data-product-id="${productId}"]`).closest('tr').remove();
                                    } else {
                                        alert(delete_product_json_response.message);
                                    }
                                } catch (error) {
                                    console.error('Error parsing the response:', error);
                                    alert('An error occurred while processing the request.');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error('Error:', error);
                                alert('An error occurred while deleting the product.');
                            }
                        });
                    }
                }
            </script>
        </div>
        <script src="javascript_files/jquery-3.6.1.min.js"></script>
        <script src="sweetalert/jquery-3.7.1.min.js"></script>
        <script src="sweetalert/bootstrap.bundle.min.js"></script>
        <script src="sweetalert/sweetalert2@11.js"></script>
        <script>
            var inventory_title = "<?php if (empty($_SESSION['inventory_title'])) {echo htmlspecialchars_decode($_SESSION['inventory_title'] = '');} else {echo htmlspecialchars_decode($_SESSION['inventory_title']);} ?>";
            var inventory_text = "<?php if (empty($_SESSION['inventory_text'])) {echo htmlspecialchars_decode($_SESSION['inventory_text'] = '');} else {echo htmlspecialchars_decode($_SESSION['inventory_text']);} ?>";
            var inventory_icon = "<?php if (empty($_SESSION['inventory_icon'])) {echo htmlspecialchars_decode($_SESSION['inventory_icon'] = '');} else {echo htmlspecialchars_decode($_SESSION['inventory_icon']);} ?>";

            if (inventory_title != '' && inventory_text != '' && inventory_icon != '') {
                Swal.fire({title: inventory_title,text: inventory_text,icon: inventory_icon});
            }

            <?php unset($_SESSION['inventory_title']); unset($_SESSION['inventory_text']); unset($_SESSION['inventory_icon']); ?>
        </script>
    </body>
</html>
<?php $db_connection->close(); ?>