<?php
    require 'database_connection.php';

    header('Content-Type: application/json');

    $productId = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['product_id']),ENT_QUOTES,'UTF-8')));
    $productName = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['product_name']),ENT_QUOTES,'UTF-8')));
    $productPrice = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['product_price']),ENT_QUOTES,'UTF-8')));
    $productQuantity = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['product_quantity']),ENT_QUOTES,'UTF-8')));

    if (empty($productId) || empty($productName) || empty($productPrice) || empty($productQuantity)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid input. Please check the details and try again.']);
        exit();
    }

    $update_product_sql = 'UPDATE `products` SET `product_name`=?, `product_price`=?, `product_quantity`=? WHERE `product_id`=?';
    $update_product_stmt = $db_connection->prepare($update_product_sql);
    $update_product_stmt->bind_param('ssss', $productName, $productPrice, $productQuantity, $productId);

    if ($update_product_stmt->execute()) {
        $available_products_sql = 'SELECT `product_id`, `product_name`, `product_price`, `product_quantity`, `product_date_created` FROM `products` WHERE `product_id`=?';
        $available_products_stmt = $db_connection->prepare($available_products_sql);
        $available_products_stmt->bind_param('s', $productId);
        $available_products_stmt->execute();
        $available_products_stmt_result = $available_products_stmt->get_result();
        $available_products_assoc = $available_products_stmt_result->fetch_assoc();
        $updatedProduct = [
            'product_id' => $available_products_assoc['product_id'],
            'product_name' => $available_products_assoc['product_name'],
            'product_price' => $available_products_assoc['product_price'],
            'product_quantity' => $available_products_assoc['product_quantity'],
            'product_date_created' => $available_products_assoc['product_date_created']
        ];

        echo json_encode(['status' => 'success', 'message' => 'Product updated successfully', 'data' => $updatedProduct]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'There was an error updating the product']);
    }

    $update_product_stmt->close();
    $available_products_stmt->close();
    $db_connection->close();
?>