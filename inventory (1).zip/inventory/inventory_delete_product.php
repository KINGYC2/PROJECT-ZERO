<?php
    require 'database_connection.php';

    if (isset($_POST['product_id'])) {
        $product_id = mysqli_real_escape_string($db_connection,stripslashes(htmlspecialchars(trim($_POST['product_id']),ENT_QUOTES,'UTF-8')));

        $select_product_id_sql = 'SELECT `product_id` FROM `products` WHERE `product_id`=?';
        $select_product_id_stmt = $db_connection->prepare($select_product_id_sql);
        $select_product_id_stmt->bind_param('s', $product_id);
        $select_product_id_stmt->execute();
        $select_product_id_result = $select_product_id_stmt->get_result();

        if ($select_product_id_result->num_rows === 1) {
            $delete_product_sql = 'DELETE FROM `products` WHERE `product_id`=?';
            $delete_product_stmt = $db_connection->prepare($delete_product_sql);
            $delete_product_stmt->bind_param('s', $product_id);
            $delete_product_stmt->execute();

            if ($delete_product_stmt->affected_rows === 1) {
                echo json_encode(['status' => 'success', 'message' => 'Product deleted successfully.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error deleting product.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Product not found.']);
        }
        $select_product_id_stmt->close();
        $delete_product_stmt->close();
        $db_connection->close();
    }
?>