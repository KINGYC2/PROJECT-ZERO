<?php
    $server_name = "127.0.0.1";
    $database_username = "root";
    $database_password = "";
    $database_name = "inventory";
    $db_connection = mysqli_connect($server_name, $database_username, $database_password, $database_name);

    if (!$db_connection) {
       die("db_connection failed: ".mysqli_connect_error());
    }
?>