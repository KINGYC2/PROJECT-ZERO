<?php
    require 'database_connection.php';

    $available_products_sql = 'SELECT `product_id`, `product_name`, `product_price`, `product_quantity`, `product_date_created` FROM `products` ORDER BY `product_id` ASC';
    $available_products_stmt = $db_connection->prepare($available_products_sql);
    $available_products_stmt->execute();
    $available_products_stmt_result = $available_products_stmt->get_result();

    $products = [];

    if ($available_products_stmt_result->num_rows > 0) {
        while ($row = $available_products_stmt_result->fetch_assoc()) {
            $products[] = [
                'product_id' => $row['product_id'],
                'product_name' => $row['product_name'],
                'product_price' => $row['product_price'],
                'product_quantity' => $row['product_quantity'],
                'product_date_created' => $row['product_date_created']
            ];
        }
    }
    
    echo json_encode($products);

    $db_connection->close();
?>